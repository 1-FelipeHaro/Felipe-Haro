﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int A, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, R;
            A = 1;

            Console.WriteLine("Digite 15 números inteiros");

            //entrada//
            do
            {
                Console.WriteLine("Número " + A++);
                a1 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a2 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a3 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a4 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a5 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a6 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a7 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a8 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a9 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a10 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a11 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a12 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a13 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a14 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a15 = int.Parse(Console.ReadLine());
                Console.WriteLine();

                Console.WriteLine("Número " + A++);
                a1 = int.Parse(Console.ReadLine());
                Console.WriteLine();
            } 
            while (A == 14);

            R = (new int[] { a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15 }).Max();   //Usei o Google para pesquisar sobre o .Max()//

            //Saída//
            Console.WriteLine("O maior número dos 15 é: " + R);
        }
    }
}