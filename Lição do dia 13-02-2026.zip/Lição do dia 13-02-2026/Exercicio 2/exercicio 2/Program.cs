﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a, b,c, n;
            Console.WriteLine("Escolha minimo:");
            a = int.Parse(Console.ReadLine());

            Console.WriteLine("Escolha o maximo:");
            b = int.Parse(Console.ReadLine());

            for (a = a; a <= b;) {
                if (a % 2 == 1)
                Console.WriteLine(a);
                a++;
            }


        }
    }
}