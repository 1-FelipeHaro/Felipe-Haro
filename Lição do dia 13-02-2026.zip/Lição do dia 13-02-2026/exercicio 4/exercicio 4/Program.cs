﻿using System;

namespace MeuProjeto
{
    class Program
    {
        static void Main(string[] args)
        {
            int nota = 0, media, soma = 0,contador;

            for (contador = 1; contador < 11; contador++) {
                Console.WriteLine($"digite 10 notas de 0 ate 10:\n ");
                nota = int.Parse(Console.ReadLine());
                
                if (nota < 0 || nota > 10
)
                {
                    Console.WriteLine("incorreto notas somente de 0 ate 10.");

                }
                else {
                    soma = soma + nota;
                    media = soma / 10;
                    Console.WriteLine("essa e a media:\n" + media);
                }
            }
            
            
        }
        
    }
}
