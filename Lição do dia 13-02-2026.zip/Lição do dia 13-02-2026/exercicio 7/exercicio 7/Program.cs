﻿using System;
using System.ComponentModel.Design;

namespace MeuProjeto
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("pessoa 1 qual o seu nome?\n");
            string nm1 = Console.ReadLine();
            Console.WriteLine("pessoa 2 qual o seu nome?\n");
            string nm2 = Console.ReadLine();
            Console.WriteLine( nm1 + " qual o dia do seu aniversario?\n");
            int d1 = int.Parse(Console.ReadLine());
            Console.WriteLine( nm2 + " qual o dia do seu aniversario?\n");
            int d2 = int.Parse(Console.ReadLine());
            Console.WriteLine( nm1 + " qual o mes do seu aniversario?\n");
            int m1 = int.Parse(Console.ReadLine());
            Console.WriteLine( nm2 + " qual o mes do seu aniversario?\n");
            int m2 = int.Parse(Console.ReadLine());

            if (m1 < m2)
            {
                Console.WriteLine(nm1 + " faz aniversario primeiro");
            }
            else if (m1 > m2)
            {
                Console.WriteLine(nm2 + " faz aniversario primeiro");
            }
            else
            {
                if (d1 < d2)
                {
                    Console.WriteLine(nm1 + " faz aniversario primeiro");
                }
                else if (d1 > d2)
                {
                    Console.WriteLine(nm2 + " faz aniversario primeiro");
                }
                else
                {
                    Console.WriteLine("Os dois fazem aniversario no mesmo dia");
                }
            }


        }

    }
}
