﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;
                for (i = 211; i < 250; i++)
            {
                if (i % 2 == 0)
                Console.WriteLine(i);
            }
        }
    }
}