﻿using System; 

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n, W, E, V, T;
            string S = "";

            while (true)
            {

                while (true)
                {
                    //início Lógica
                    Console.WriteLine("Digite a quantidade de horas de trabalhadas");
                    n = int.Parse(Console.ReadLine());


                    if (n <= 50)
                    {
                        T = n * 10.00;
                        E = 0;
                        Console.WriteLine("Relatório de trabalho");
                        Console.WriteLine();
                        Console.WriteLine($"Salario total:{T}");
                        Console.WriteLine();
                        Console.WriteLine($"Horas extras:{E}");
                        Console.WriteLine();
                    }

                    else
                    {
                        W = n * 10.00;
                        V = W - 500;
                        E = V * 2;
                        Console.WriteLine("Relatório de trabalho");
                        Console.WriteLine();
                        Console.WriteLine($"Salario total:{W}");
                        Console.WriteLine();
                        Console.WriteLine($"Horas extras:{E}");
                        Console.WriteLine();
                    }

                    //finalizar sistema
                    Console.WriteLine("Se deseja encerar o programa digite S, se não, tecle enter");
                    S = (Console.ReadLine());

                    if (S.ToLower() == "S")
                    { Console.ReadKey(); }
                }

            }
        }
    }
}